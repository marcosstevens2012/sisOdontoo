<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="proveedor">Paciente</label>
				<p><?php echo e($paciente->nombre . " " . $paciente->apellido); ?></p>
			</div>
		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label>Obra Social</label>
				<p><?php echo e($paciente->obrasocial); ?></p>
			</div>
		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="serie_comprobante">Tipo Sangre</label>
				<p><?php echo e($paciente->tipo_sangre); ?></p>
			</div>
		</div>

		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="serie_comprobante">Carnet</label>
				<p><?php echo e($paciente->carnet); ?></p>
			</div>
		</div>

		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="serie_comprobante">Alertas</label>
				<p><?php echo e($paciente->contradicciones); ?></p>
			</div>
		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="serie_comprobante">Saldo</label>
				<p><?php echo e($paciente->saldo); ?></p>
			</div>
		</div>
		
	</div>
		
	<div class="row">
		<div class="panel panel-primary">
			<div class="panel-body">
				<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
					<table id="detalles" class="table table-striped table-bordered table-condensed">
						<thead style="background-color: #ccc">
							<th>Tratamiento</th>
							<th>Fecha</th>
						</thead>
						<tfoot>
							<th></th>
							<th></th>
						</tfoot>
						<tbody>
							<?php foreach($odontograma as $odo): ?>
							<tr>
								<td><?php echo e($odo->estados); ?></td>
								<td><?php echo e($odo->fechaRegistro); ?></td>
							
							</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
			
		</div>
		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>