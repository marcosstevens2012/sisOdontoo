<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<h3>Editar persona </h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php foreach($errors->all() as $error): ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>
		</div>
	</div>
	<?php echo Form::model($profesional, ['method'=>'PATCH', 'route'=>['profesional.profesional.update', $profesional->idprofesional],'files'=>'true']); ?>

	<?php echo e(Form::token()); ?>

	<div class="row">
		
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group ">
				<label> Nombre</label>
				<input class='form-control' title="Se necesita un nombre" value="<?php echo e($persona->nombre); ?>" type="text" name="nombre" required/>
			</div>
		</div>

		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group ">
				<label>Apellido</label>
				<input class='form-control' style="text-transform:uppercase;" onkeyup="aMays(event, this)" onblur="aMays(event, this)" title="Se necesita un Apellido" required value="<?php echo e($persona->apellido); ?>" type="text" name="apellido" required/>

			</div>
		</div>


		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label>Consultorio</label>
				<select name="pconsultorio" id="pconsultorio" class="form-control selectpicker" data-live-search="true">
					<?php foreach($consultorios as $con): ?>
						<option value="<?php echo e($con->idconsultorio); ?>"><?php echo e($con->numero); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>

		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label>Nacimiento</label>
				<input type="date" name="nacimiento" id='nacimiento' title="Se necesita fecha" required value="<?php echo e(old('nacimiento')); ?>" class="form-control" placeholder="Nacimiento">
			</div>
		</div>

		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label>Tipo Documento</label>
				<select name="idtipo_documento" id="idtipo_documento" class="form-control selectpicker" data-live-search="true">
					<?php foreach($tipodocumentos as $doc): ?>
						<option value="<?php echo e($doc->idtipo_documento); ?>"><?php echo e($doc->nombre); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label name="documento" for="dni">Documento</label>
				<input name="documento" type="number"  class="form-control" required value="<?php echo e($persona->documento); ?>" placeholder="DNI">
			</div>
		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label name="direccion" for="direccion">Direccion</label>
				<input name="direccion" style="text-transform:uppercase;" onkeyup="aMays(event, this)" onblur="aMays(event, this)" id="direccion" type="text"  class="form-control" required value="<?php echo e($persona->direccion); ?>" placeholder="Direccion">
			</div>
		</div>

		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<label for="fecha">Pais</label>
			<div class="form-group">
				<select name="paisnombre" id="paisnombre" class="paisnombre form-control " data-live-search="true"  >
					<?php foreach($pais as $pai): ?>
						<option value="<?php echo e($pai->idciudad); ?>"><?php echo e($pai->ciudad); ?></option>
						
						
					<?php endforeach; ?>
				</select>
			</div>
		</div>




		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="fecha">Provincia</label>
				<select name="provincianombre" id="provincianombre" class="provincianombre form-control" >
					<option required value="0" disabled="true" selected="true">Seleccione Provincia</option>
				</select>
			</div>
		</div>

		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="fecha">Ciudad</label>
				<select name="ciudadnombre" id="ciudadnombre" class="ciudadnombre form-control"  >
					<option  value="0" disabled="true" selected="true" name="ciudadnombre" >Seleccione</option>
				</select>
			</div>
		</div>

		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="telefono">Telefono</label>
				<input type="tel" name="telefono"  class="form-control" required value="<?php echo e($persona->telefono); ?>" placeholder="Telefono">
			</div>
		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="fecha">Email</label>
				<input type='email' class='form-control' name="email" required value="<?php echo e($persona->email); ?>" required 
				pattern="[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*@[a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{1,5}" placeholder="Email">
			</div>
		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="observaciones">Observaciones</label>
				<textarea name="observaciones" style="text-transform:uppercase;" onkeyup="aMays(event, this)" onblur="aMays(event, this)" id="observaciones" class="form-control" rows="5" cols="10" required value="" placeholder="Observaciones" required><?php echo e($persona->observaciones); ?> </textarea>
			</div>
		</div>
		
		
		<div class="col-md-6 col-md-offset-3">
			<div class="col-md-6 col-md-offset-3">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>
		</div>

	</div>

	<?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>