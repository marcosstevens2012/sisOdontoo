<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="cliente">Paciente Sin Obra Social</label>
				<p><?php echo e($transaccion->nombre); ?> <?php echo e($transaccion->apellido); ?></p>
			</div>
		</div>

		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="fecha_hora">Fecha y Hora</label>
				<p><?php echo e($transaccion->fecha_hora); ?></p>
			</div>
		</div>
	</div>
		
	<div class="row">
		<div class="panel panel-primary">
			<div class="panel-body">
				<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
					<table id="detalles" class="table table-striped table-bordered table-condensed">
						<thead style="background-color: #ccc">
							<th>Prestacion</th>
							<th>Coseguro</th>
							<th>Forma de Pago</th>
							<th>subtotal</th>
						</thead>
						<tfoot>
							<th></th>
							<th></th>
							<th></th>
							<th><h4 id="total">$ <?php echo e($transaccion->total_transaccion); ?></h4></th>
						</tfoot>
						<tbody>
							<?php foreach($detalles as $det): ?>
							<tr>
								<td><?php echo e($det->prestacion); ?></td>
								<td>$ <?php echo e($det->importe); ?></td>
								<td><?php echo e($det->pago); ?>

								<td>$ <?php echo e($det->importe); ?></td>
							</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
			
		</div>
		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>