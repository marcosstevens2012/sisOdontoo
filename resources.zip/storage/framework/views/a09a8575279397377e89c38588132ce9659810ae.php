<?php $__env->startSection('contenido'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
	<div class="row">
		<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
			<h3>Listado de Profesionales <a href="profesional/create"><button class="btn btn-success">Nuevo</button></a></h3>
			<?php echo $__env->make('profesional.profesional.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="table-responsive">
				<table id="example1" class= "table table-striped table-bordered table-condensed table-hover">
					<thead>
					
						<th>Nombre</th>
						<th>Apellido</th>
						<th>Documento</th>
						<th>Matricula</th>
						<th>Telefono</th>
						<th>Email</th>
						<th>Opciones</th>
					
					</thead>
					<tbody>
					<!-- bucle -->
					<?php foreach($profesionales as $pro): ?>
					<tr>
						<td style="text-align: center;"><?php echo e($pro->nombre); ?></td>
						<td style="text-align: center;"><?php echo e($pro->apellido); ?></td>
						<td style="text-align: center;"><?php echo e($pro->dni); ?></td>
						<td style="text-align: center;"><?php echo e($pro->matricula); ?></td>
						<td style="text-align: center;"><?php echo e($pro->telefono); ?></td>
						<td style="text-align: center;"><?php echo e($pro->email); ?></td>
						<td>
							<a href="<?php echo e(URL::action('ProfesionalController@edit', $pro->idprofesional)); ?>"><button class="btn btn-info">Editar</button></a>
							<a href="<?php echo e(URL::action('PrestacionProfesionalController@index', ['idprofesional'=>$pro->idprofesional])); ?>"><button class="btn .btn.bg-maroon">Prestaciones</button></a>
							<a href="" data-target="#modal-delete-<?php echo e($pro->idprofesional); ?>" data-toggle="modal"><button class="btn btn-danger"> Eliminar</button></a>
						</td>
					</tr>
					
					<?php echo $__env->make('profesional.profesional.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php endforeach; ?>
					</tbody>
					
				</table>
				
			</div>
			<?php echo e($profesionales->render()); ?>

			
		</div>

	</div>
<?php $__env->startPush('scripts'); ?>

<script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>


<script type="text/javascript">
$(document).ready(function(){
    $('#example1').DataTable();
});

</script>

<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>