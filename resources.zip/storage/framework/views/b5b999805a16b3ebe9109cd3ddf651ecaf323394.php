<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-md-6 col-md-offset-3">
			<h3>Editar Turno <?php echo e($turno->hora_inicio); ?></h3>
			<?php if(count($errors)>0): ?>
			<div class="alert alert-danger">
				<ul>
					<?php foreach($errors->all() as $error): ?>
					<li><?php echo e($error); ?></li>
					<?php endforeach; ?>
				</ul>
			</div>
			<?php endif; ?>
		</div>
	</div>
	<?php echo Form::model($turno, ['method'=>'PATCH', 'route'=>['turno.turno.update', $turno->idturno],'files'=>'true']); ?>

	<?php echo e(Form::token()); ?>

	<div class="row">
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group ">
				<label clas=>Paciente</label>
				<select name="idpaciente" id="idpaciente" class="form-control selectpicker" data-live-search="true">
					<?php foreach($personas as $per): ?>
					<?php if($per->idpaciente==$turno->idpaciente): ?>
					<option value="<?php echo e($per->idpaciente); ?>" selected><?php echo e($per->nombre . " " . $per->apellido); ?></option>
					<?php else: ?>
					<option value="<?php echo e($per->idpaciente); ?>"><?php echo e($per->nombre . " " . $per->apellido); ?></option>
					<?php endif; ?>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label>Profesional</label>
				<select name="idprofesional" id="idprofesional" class="form-control selectpicker" data-live-search="true">
					<?php foreach($profesionales as $pro): ?>
						<?php if($pro->idprofesional==$turno->idprofesional): ?>
					<option value="<?php echo e($pro->idprofesional); ?>" selected><?php echo e($pro->nombre . " " . $pro->apellido); ?></option>
					<?php else: ?>
					<option value="<?php echo e($pro->idprofesional); ?>"><?php echo e($pro->nombre . " " . $pro->apellido); ?></option>
					<?php endif; ?>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label>Prestaciones</label>
				<select name="idprestacion" id="idprestacion" class="form-control selectpicker" data-live-search="true">
					<?php foreach($prestaciones as $pre): ?>
						<?php if($pre->idprestacion==$turno->idprestacion): ?>
					<option value="<?php echo e($pre->idprestacion); ?>" selected><?php echo e($pre->nombre); ?></option>
					<?php else: ?>
					<option value="<?php echo e($pre->idprestacion); ?>"><?php echo e($pre->nombre); ?></option>
					<?php endif; ?>
					<?php endforeach; ?>
				</select>
			</div>
		</div>

		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label>Estado</label>
				<select name="idestado" id="idestado" class="form-control selectpicker" data-live-search="true">
					<?php foreach($estados as $est): ?>
					<option value="<?php echo e($est->idestado_turno); ?>"><?php echo e($est->estado); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="FECHA">Fecha</label>
				<input type="date" name="fecha" required value="<?php echo e($turno->fecha); ?>" class="form-control" placeholder="Fecha" required >
			</div>
		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="hora_inicio">Hora Inicio</label>
				<input type="time" name="hora_inicio" required value="<?php echo e($turno->hora_inicio); ?>" class="form-control" placeholder="Hora Inicio">
			</div>
		</div>
		
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="hora_fin">Hora Fin</label>
				<input type="time" name="hora_fin" required value="<?php echo e($turno->hora_fin); ?>" class="form-control" placeholder="Hora Fin">
			</div>
		</div>
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="form-group">
				<label for="observaciones">Observaciones</label>
				<textarea name="observaciones" required value="<?php echo e($turno->observaciones); ?>" class="form-control" rows="5" cols="10" placeholder="Observaciones" required> </textarea>
			</div>
		</div>
		
	
		
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<div class="col-md-6 col-md-offset-3">
				<button class="btn btn-primary" type="submit">Guardar</button>
				<button class="btn btn-danger" type="reset">Cancelar</button>
			</div>
		</div>
	</div>

	<?php echo Form::close(); ?>


	<!-- jQuery 3 -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>