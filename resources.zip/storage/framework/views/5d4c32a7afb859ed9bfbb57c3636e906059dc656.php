<?php $__env->startSection('contenido'); ?>
	<div class="row">
		<div class="col-lg-6 col-sm-6 col-md-6 col-xs-12">
			<h3>Listado de Turnos <a href="turno/create"><button class="btn btn-success">Nuevo</button></a>
			<br><br>
			<?php echo $__env->make('turno.turno.search', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>
	<?php if(Session::has('notice')): ?><!-- crea una alerta de q ha sido creado correctamente el usuario-->
   					<div class="alert alert-info">
   					<a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
    				<strong>Notice:</strong> <?php echo e(Session::get('notice')); ?></div>
    <?php endif; ?>
	<div class="row">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<div class="table-responsive">
				<table id="example1" class="table table-bordered table-striped">
					<thead>
						
						<th>Paciente</th>
						<th>Prestacion</th>
						<th>Profesional</th>
						<th>Estado</th>
						<th>Inicio</th>
						<th>Fecha</th>
						<th>Opciones</th>
					</thead>
					<!-- bucle -->
					<?php foreach($turnos as $tur): ?>
					<tr>
						<td align="center"><?php echo e($tur->paciente); ?></td>
						<td align="center" ><?php echo e($tur->prestacion); ?></td>
						<td align="center"><?php echo e($tur->profesional); ?></td>
						<?php if($tur->estado=='Activo'): ?>
						<td align="center"><small class="label pull-right bg-green"><?php echo e($tur->estado); ?></small></td>
						<?php elseif($tur->estado=='Pendiente'): ?>
						<td align="center"><small class="label pull-right bg-yellow"><?php echo e($tur->estado); ?></small></td>
						<?php else: ?>
						<td align="center"><small class="label pull-right bg-red"><?php echo e($tur->estado); ?></small></td>
						<?php endif; ?>
						<td align="right"><?php echo e($tur->hora_inicio); ?></td>
						
						<td align="right"> <?php 
												$originalDate = $tur->fecha;
        										$newDate = date("d-m-Y", strtotime($originalDate));

											?><?php echo e($newDate); ?></td>
						<td>
						<?php if($tur->estado=='Pendiente' ): ?>
						<a href="<?php echo e(URL::action('TurnoController@edit', $tur->idturno)); ?>"><button class="btn-xs btn-primary"> Estado</button></a>
						<a href="" data-target="#modal-delete-<?php echo e($tur->idturno); ?>" data-toggle="modal"><button class="btn-xs btn-success">En Consultorio</button></a>
						<?php endif; ?>
						<?php if($tur->estado =='Pendiente' || $tur->estado =='En consultorio'): ?>
						<a href="<?php echo e(URL::action('PacienteController@show' , $tur->idpaciente)); ?>"><button class="btn-xs btn-primary">Paciente</button></a>
						<?php endif; ?>
						<?php if($tur->estado!='Pendiente' ): ?>
						<a href="<?php echo e(URL::action('TransaccionController@create', ['idpaciente'=>$tur->idpaciente])); ?>"><button class="btn .btn.bg-maroon">Cobrar</button></a>
						<?php endif; ?>
              			<a href="<?php echo e(URL::action('TurnoController@show', $tur->idturno)); ?>"><button class="btn-xs btn-info"> Seguimiento</button></a>
              			<a href="<?php echo e(URL::action('PdfturnoController@show', $tur->idturno)); ?>"><button class="btn-xs btn-info">Reporte</button></a></td>
					</tr>
					<?php echo $__env->make('turno.turno.modal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php endforeach; ?>
				</table>
				
			</div>
			<?php echo e($turnos->render()); ?>

			
		</div>

	</div>

<script type="text/javascript">
$(document).ready(function(){
    $('#example1').DataTable({


    	"language": {
            "url": "//cdn.datatables.net/plug-ins/1.10.16/i18n/Spanish.json"
     }
    } );
} 
);

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>