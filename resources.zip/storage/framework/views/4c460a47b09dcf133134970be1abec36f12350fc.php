<?php $__env->startSection('contenido'); ?>

	<div class="row">
		<div class="panel panel-primary">
			<div class="panel-body">
				<div class="col-lg-12 col-sm-12 col-md-12 col-xs-12">
					<table id="detalles" class="table table-striped table-bordered table-condensed">
						<thead style="background-color: #ccc">
							<th>Turno</th>
							<th>Estado</th>
							<th>Modificado</th>
							<th>Finalizado</th>
							<th>Observaciones</th>
						</thead>
						<tfoot>
							<th></th>
							<th></th>
							<th></th>
							<th></th>
							<th></th>
						</tfoot>
						<tbody>
							<?php foreach($turno as $tur): ?>
							<tr>
								<td><?php echo e($tur->idturno); ?></td>
								<td><?php echo e($tur->estado); ?></td>
								<td><?php echo e($tur->inicio); ?></td>
								<td><?php echo e($tur->fin); ?></td>
								<td><?php echo e($tur->observaciones); ?></td>
							</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>
			
		</div>
		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>