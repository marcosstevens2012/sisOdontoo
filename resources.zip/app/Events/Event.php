<?php

namespace sisOdonto\Events;

abstract class Event
{
    //
}
