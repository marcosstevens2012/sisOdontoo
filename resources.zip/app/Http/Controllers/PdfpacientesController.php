<?php

namespace sisOdonto\Http\Controllers;

use Illuminate\Http\Request;

use sisOdonto\Http\Requests;

class PdfpacientesController extends Controller
{
    //
}
