<?php

namespace sisOdonto;

use Illuminate\Database\Eloquent\Model;

class Clinica extends Model
{
    //
}
