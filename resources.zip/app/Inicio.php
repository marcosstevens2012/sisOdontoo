<?php

namespace sisOdonto;

use Illuminate\Database\Eloquent\Model;

class Inicio extends Model
{
    //
}
