
<div class='aprobado'><label style='color:#177F6B'>
              <?php  echo $msj; ?>  
</div>
            
       