<?php
use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $this->call(PacienteSeeder::class);
        //$this->call(PacienteSeeder::class);
        //$this->call(CreateUsersTable::class);
        //$this->call(ProfesionalSeeder::class);
        //$this->call(ObrasocialSeeder::class);
        //$this->call(TurnoSeeder::class);
    }
}
